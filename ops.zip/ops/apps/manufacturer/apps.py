from django.apps import AppConfig


class ManufacturerConfig(AppConfig):
    name = 'manufacturer'
