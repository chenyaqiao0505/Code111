from django.apps import AppConfig


class CabinetConfig(AppConfig):
    name = 'cabinet'
